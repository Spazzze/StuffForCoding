android-studio-Obsidian-theme
=============================

Installation
---------

1.  Copy `Obsidian.icls` to your IntelliJ IDEA preferences color directory. 

    *Mac OS X*
    * `~/Library/Preferences/AndroidStudio/colors`
    * `~/Library/Preferences/AndroidStudio2.0/colors`
    * `~/Library/Preferences/IntelliJIdea14/colors` (IntelliJ IDEA 14 Ultimate Edition)
    * `~/Library/Preferences/IdeaIC14/colors` (IntelliJ IDEA 14 Community Edition)
    *Windows*
    * `Documents and Settings/<user>/.IdeaIC12/config/colors` (IntelliJ IDEA 12 Community Edition)
        
2. Restart IntelliJ IDEA / Android Studio

3. Go to `Preferences | Editor | Colors & Fonts` and select Obsidian
color themes.


<img src="https://github.com/Tengag/android-studio-Obsidian-theme/blob/master/Obsidian-screen.png">
